var _cmd_orders_dlg_8cpp =
[
    [ "DEF_MAP_CLIENT", "_cmd_orders_dlg_8cpp.html#aa88ea95b000d860229c4d07ac601efbb", null ],
    [ "DEF_MAP_CLIENT", "_cmd_orders_dlg_8cpp.html#ac66f724437d99b81f52b2981d4dd97d8", null ],
    [ "DEF_MAP_CLIENT", "_cmd_orders_dlg_8cpp.html#ad4b841aa52c84a7c260b9f4c548cbf9e", null ]
];