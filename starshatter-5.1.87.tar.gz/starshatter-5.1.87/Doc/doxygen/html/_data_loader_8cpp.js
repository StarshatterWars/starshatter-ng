var _data_loader_8cpp =
[
    [ "archives", "_data_loader_8cpp.html#ae6c6241aac2aad1bc213daec64e25a0c", null ],
    [ "def_loader", "_data_loader_8cpp.html#a6adfb51c813477cb3ef60aadca76d946", null ]
];