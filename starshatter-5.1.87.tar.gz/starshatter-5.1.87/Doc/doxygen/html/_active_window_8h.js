var _active_window_8h =
[
    [ "AWEvent", "struct_a_w_event.html", "struct_a_w_event" ],
    [ "AWMap", "struct_a_w_map.html", "struct_a_w_map" ],
    [ "ActiveWindow", "class_active_window.html", "class_active_window" ],
    [ "DEF_MAP_CLIENT", "_active_window_8h.html#acf5ab5423841bdc2aaaf6da32a059111", null ],
    [ "REGISTER_CLIENT", "_active_window_8h.html#ac1272bb20299d2bb29ec908188ecc7b6", null ],
    [ "UNREGISTER_CLIENT", "_active_window_8h.html#a3f843decfee764010dc3fa0b21ff9c03", null ],
    [ "PFVAWE", "_active_window_8h.html#a51a9b02cfd470a4ecbb0e48c111617f7", null ]
];