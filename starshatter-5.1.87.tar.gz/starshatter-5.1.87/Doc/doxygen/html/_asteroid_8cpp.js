var _asteroid_8cpp =
[
    [ "asteroid_model", "_asteroid_8cpp.html#ae333a959c651e75bf51f0ce5b79b3710", null ],
    [ "asteroid_velocity", "_asteroid_8cpp.html#a7da4afe698fb4fb6a9e05432d02ad21e", null ]
];