var _authorization_8cpp =
[
    [ "execRegistrationProgram", "_authorization_8cpp.html#a576ccedcc5aa7ba7d29e05bb97ec7268", null ],
    [ "GetCDKeyFromIniFile", "_authorization_8cpp.html#ae67378139624619f26f36124f95a03a6", null ],
    [ "GetCDKeyFromRegistry", "_authorization_8cpp.html#a12f67cbad2be51cdd76093ee03239cf1", null ],
    [ "serial_number", "_authorization_8cpp.html#ad29c9c5615272f2202344e705de6b83f", null ]
];