var _exit_dlg_8cpp =
[
    [ "DEF_MAP_CLIENT", "_exit_dlg_8cpp.html#aab4d894efb285ee73c804e25a6068e48", null ],
    [ "DEF_MAP_CLIENT", "_exit_dlg_8cpp.html#a2572846adafa2ce82fea3d8e1bcc34d4", null ]
];