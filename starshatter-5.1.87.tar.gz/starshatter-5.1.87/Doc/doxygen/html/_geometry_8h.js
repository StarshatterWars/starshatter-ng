var _geometry_8h =
[
    [ "Rect", "struct_rect.html", "struct_rect" ],
    [ "Insets", "struct_insets.html", "struct_insets" ],
    [ "Matrix", "struct_matrix.html", "struct_matrix" ],
    [ "Vec2", "struct_vec2.html", "struct_vec2" ],
    [ "Vec3", "struct_vec3.html", "struct_vec3" ],
    [ "Point", "struct_point.html", "struct_point" ],
    [ "Quaternion", "struct_quaternion.html", "struct_quaternion" ],
    [ "Plane", "struct_plane.html", "struct_plane" ],
    [ "ClosestApproachTime", "_geometry_8h.html#ab39783d01e187be03014895f5e7e118d", null ],
    [ "ClosestApproachTime", "_geometry_8h.html#ad3944c476d46188249376f290a934d21", null ],
    [ "CrossProduct", "_geometry_8h.html#a7b32f095e9c893be8afb27d1310bfa1f", null ],
    [ "DotProduct", "_geometry_8h.html#af507df72c2927886430fa6c25be87b82", null ],
    [ "lines_intersect", "_geometry_8h.html#abe89a66a9f9ef5d6a7c9feca1cfe13ed", null ],
    [ "MConcat", "_geometry_8h.html#aca1d3b40ee7c81df67a92b3fd102148c", null ],
    [ "DEGREES", "_geometry_8h.html#a530d0fdbd8b1d8b27d9dffd58969e394", null ],
    [ "PI", "_geometry_8h.html#a952eac791b596a61bba0a133a3bb439f", null ]
];