var _combat_group_8cpp =
[
    [ "GET_DEF_BOOL", "_combat_group_8cpp.html#a1782f119c5998b2b14ca43ccd3be8df7", null ],
    [ "GET_DEF_NUM", "_combat_group_8cpp.html#a29a5ceb5c98491b5559ad38627a90c87", null ],
    [ "GET_DEF_TEXT", "_combat_group_8cpp.html#ad2ddf97844b988ca8bef6fe58c06b774", null ],
    [ "GET_DEF_VEC", "_combat_group_8cpp.html#a367f5bbd51aa8cd521ee80bb7be74e79", null ],
    [ "FormatNumber", "_combat_group_8cpp.html#a0a789b98d5d2d3fe5d4663a4a0b84be7", null ],
    [ "SaveCombatGroup", "_combat_group_8cpp.html#ac2a14ee46b163d288c397917122b7686", null ],
    [ "SaveCombatUnit", "_combat_group_8cpp.html#ad3a04ed47269a6c915d9ccc494fb99bd", null ],
    [ "ShipClassFromName", "_combat_group_8cpp.html#a5a8ab09014ec6fdf39bc5d0b1ce696da", null ],
    [ "group_name", "_combat_group_8cpp.html#a7bbd5f2074e5ae1f0fdfe52c0f5a1b31", null ]
];