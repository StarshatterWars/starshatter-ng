var _fighter_tactical_a_i_8cpp =
[
    [ "WINCHESTER_ASSAULT", "_fighter_tactical_a_i_8cpp.html#ad74605cc9e12bf65a3331273faba0ee4", null ],
    [ "WINCHESTER_FIGHTER", "_fighter_tactical_a_i_8cpp.html#a1145802cf7138533b9b6fb7e6657d13e", null ],
    [ "WINCHESTER_STATIC", "_fighter_tactical_a_i_8cpp.html#a913ba58d0d9a8c355f38f15804b9d56b", null ],
    [ "WINCHESTER_STRIKE", "_fighter_tactical_a_i_8cpp.html#af9406177983e128c2a513164f8749df1", null ]
];