var _fighter_a_i_8cpp =
[
    [ "frame_time", "_fighter_a_i_8cpp.html#a4d0e0c97bc8525b8edbe85b655f1861d", null ],
    [ "TIME_TO_DOCK", "_fighter_a_i_8cpp.html#a3a8c2b34413f5be96b24b78d61084416", null ]
];