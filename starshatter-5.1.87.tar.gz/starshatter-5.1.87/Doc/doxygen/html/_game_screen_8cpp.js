var _game_screen_8cpp =
[
    [ "mouse_active", "_game_screen_8cpp.html#ad63fc59b349d9c992d0acf20fa3d7ca6", null ],
    [ "mouse_con", "_game_screen_8cpp.html#a45cfb7be08bef0f1c86502031eada01b", null ],
    [ "old_disp_win", "_game_screen_8cpp.html#a4c1787585935f3bd1c9b849c339be979", null ]
];