var _debrief_dlg_8cpp =
[
    [ "DEF_MAP_CLIENT", "_debrief_dlg_8cpp.html#ad60edef818713e699c73f7e01ddbc95a", null ],
    [ "DEF_MAP_CLIENT", "_debrief_dlg_8cpp.html#a6738b9a49896d1f8b710a64afbf80ed8", null ]
];