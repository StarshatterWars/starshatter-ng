var _fix_8h =
[
    [ "fix", "classfix.html", "classfix" ],
    [ "fast_f2i", "_fix_8h.html#afb5388de975bbba4d03b418d5f28585d", null ],
    [ "fix_sixty_five", "_fix_8h.html#af73843902094dfe807f38b5940ce91f0", null ]
];