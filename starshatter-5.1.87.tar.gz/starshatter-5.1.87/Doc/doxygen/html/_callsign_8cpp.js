var _callsign_8cpp =
[
    [ "alliance_catalog", "_callsign_8cpp.html#ae3c8fdab9a5fd326019b953d53c7e39f", null ],
    [ "callsign_index", "_callsign_8cpp.html#a3c1310e3e861a7ae44a2cdc13b2bec52", null ],
    [ "civilian_catalog", "_callsign_8cpp.html#aa93086fc3c3bf56e2b699392fc5d8c6e", null ],
    [ "hegemony_catalog", "_callsign_8cpp.html#afc6cac28b07ebeb0a47b44cbf5de736c", null ],
    [ "pirate_catalog", "_callsign_8cpp.html#ac12677360cb15d8379b9e358961ec5b3", null ],
    [ "zolon_catalog", "_callsign_8cpp.html#a51698bd474e51c4866cd7332b4295b31", null ]
];