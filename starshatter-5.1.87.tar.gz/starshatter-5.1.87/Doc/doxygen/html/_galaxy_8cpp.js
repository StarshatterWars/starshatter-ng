var _galaxy_8cpp =
[
    [ "galaxy", "_galaxy_8cpp.html#a1ef84b0eadabcadeffc3e234fc480e7f", null ]
];