var _color_8cpp =
[
    [ "bclamp", "_color_8cpp.html#a25cab661dba4a8b6d50ad3261b7ac784", null ],
    [ "MatchRGB", "_color_8cpp.html#ab5928159f2c900874637b39350bcb4ed", null ],
    [ "Print", "_color_8cpp.html#a76779b0ba1af4da2cfb8cf309b39372b", null ]
];