var _edit_box_8cpp =
[
    [ "GetRealTime", "_edit_box_8cpp.html#aded522acca7564f174ebe4e242865402", null ],
    [ "old_cursor", "_edit_box_8cpp.html#a54e6fa5208aa7062f120c4f918e49631", null ]
];