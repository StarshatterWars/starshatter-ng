var _alpha_palette_8cpp =
[
    [ "standard_palette", "_alpha_palette_8cpp.html#a48bb683108b62154ca72f0dcb783d531", null ]
];