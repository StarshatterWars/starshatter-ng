var _form_def_8h =
[
    [ "ColumnDef", "class_column_def.html", "class_column_def" ],
    [ "LayoutDef", "class_layout_def.html", "class_layout_def" ],
    [ "WinDef", "class_win_def.html", "class_win_def" ],
    [ "CtrlDef", "class_ctrl_def.html", "class_ctrl_def" ],
    [ "FormDef", "class_form_def.html", "class_form_def" ],
    [ "WinType", "_form_def_8h.html#a21948acce463ff0ec47d98e654cbda70", null ]
];