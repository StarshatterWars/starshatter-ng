var _form_def_8cpp =
[
    [ "CTRL_DEF_ANIMATED", "_form_def_8cpp.html#aedd18e79c7ac3bf4b73ece18dba43ce5", null ],
    [ "CTRL_DEF_BORDER", "_form_def_8cpp.html#a1b05a326045f20f976fb41612f79cccb", null ],
    [ "CTRL_DEF_DROP_SHADOW", "_form_def_8cpp.html#a4dc7e1dd56c31d0f3229087eec4e22b3", null ],
    [ "CTRL_DEF_GLOW", "_form_def_8cpp.html#acabf508a496c70e4249ddbbe0e424e35", null ],
    [ "CTRL_DEF_INDENT", "_form_def_8cpp.html#aa573c3457ea03baf92880cc2abed95a5", null ],
    [ "CTRL_DEF_INVERT_LABEL", "_form_def_8cpp.html#aa49163121a0d0670166ede485f45dea4", null ],
    [ "CTRL_DEF_SIMPLE", "_form_def_8cpp.html#a8524f1a4fd78b4689a9578e8969d52ec", null ],
    [ "CTRL_DEF_STICKY", "_form_def_8cpp.html#a2f5196550d7be6063769b46256b0f7e2", null ],
    [ "filename", "_form_def_8cpp.html#abf26ccebce8daa08c6d49277c1b12853", null ],
    [ "path_name", "_form_def_8cpp.html#aa07c998f96d42e93188e5604f5a74640", null ]
];