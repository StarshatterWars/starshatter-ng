var _contact_8cpp =
[
    [ "DEFAULT_TRACK_AGE", "_contact_8cpp.html#ae9999ce281da41d150d4e04613018e40", null ],
    [ "DEFAULT_TRACK_LENGTH", "_contact_8cpp.html#a456e95fa0c412e5d25ae19db90e66c29", null ],
    [ "DEFAULT_TRACK_UPDATE", "_contact_8cpp.html#af579ad5d2aa0bbc176409f976a3161a4", null ],
    [ "SENSOR_THRESHOLD", "_contact_8cpp.html#ae1be8e03496f6c8d68c3fa04a7dbc8cc", null ]
];