var _confirm_dlg_8cpp =
[
    [ "DEF_MAP_CLIENT", "_confirm_dlg_8cpp.html#a8d7892f7c1d19de6ddc3778b814c9113", null ],
    [ "DEF_MAP_CLIENT", "_confirm_dlg_8cpp.html#a4b7ee82d5399ee56d445d482a4bc06a9", null ]
];