var _archive_8h =
[
    [ "DataHeader", "struct_data_header.html", "struct_data_header" ],
    [ "DataEntry", "struct_data_entry.html", "struct_data_entry" ],
    [ "DataArchive", "class_data_archive.html", "class_data_archive" ],
    [ "BLOCK_SIZE", "_archive_8h.html#ad51ded0bbd705f02f73fc60c0b721ced", null ],
    [ "FILE_BLOCK", "_archive_8h.html#a2bcfc97af3ac5d06414ef862c3380c04", null ],
    [ "NAMELEN", "_archive_8h.html#a4411eb14f1a528142d32a8132e6d326c", null ],
    [ "VERSION", "_archive_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf", null ]
];