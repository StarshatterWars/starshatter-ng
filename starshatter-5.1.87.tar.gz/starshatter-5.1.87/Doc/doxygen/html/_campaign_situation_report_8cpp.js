var _campaign_situation_report_8cpp =
[
    [ "outlooks", "_campaign_situation_report_8cpp.html#a3c4ff87e8e91e0a6791014d4848a5b29", null ]
];