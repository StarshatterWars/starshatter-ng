var _bmp_8h =
[
    [ "BmpFileHeader", "struct_bmp_file_header.html", "struct_bmp_file_header" ],
    [ "BmpInfoHeader", "struct_bmp_info_header.html", "struct_bmp_info_header" ],
    [ "BmpImage", "struct_bmp_image.html", "struct_bmp_image" ],
    [ "BMP_FILE_HDR_SIZE", "_bmp_8h.html#adaab4b159029194661acd3e8f5ebe2b0", null ],
    [ "BMP_INFO_HDR_SIZE", "_bmp_8h.html#a9185e31a977af29c8953c9c8701b5930", null ]
];