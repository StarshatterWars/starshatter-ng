var _combat_zone_8cpp =
[
    [ "zonelist", "_combat_zone_8cpp.html#a81bd7357ebfec1a3ef18354df047d010", null ]
];