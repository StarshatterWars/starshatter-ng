var _award_dlg_8cpp =
[
    [ "DEF_MAP_CLIENT", "_award_dlg_8cpp.html#a4d238e9f2a27a983fb1d4fe7bb5d2ec2", null ]
];