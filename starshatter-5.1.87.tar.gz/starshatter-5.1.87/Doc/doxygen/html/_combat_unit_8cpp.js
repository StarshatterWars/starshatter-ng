var _combat_unit_8cpp =
[
    [ "KillGroup", "_combat_unit_8cpp.html#ac41aa6666520aca12ca3c485f2ea125c", null ],
    [ "random", "_combat_unit_8cpp.html#a7ba5ae854b32f4fd9f36f8dac1a27fdc", null ]
];