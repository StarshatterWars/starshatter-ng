var _computer_8cpp =
[
    [ "computer_value", "_computer_8cpp.html#aa97961d27cc65832b9c0c00bcf1db5bf", null ]
];